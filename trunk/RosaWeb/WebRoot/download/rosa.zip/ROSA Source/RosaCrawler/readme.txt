﻿						Readme
1.此项目在Eclipse下开发，可以直接使用Eclipse的import菜单导入
2.只写了部分注释，并且前期注释用英文写的，后期采用中文书写。
3.了解代码最好还是先看Document文件夹下的需求和设计说明。